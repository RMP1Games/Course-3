﻿namespace TestingPlatform.Domain.Enums
{
    public enum UserRole
    {
        Manager = 1,
        Student = 2,
    }
}
