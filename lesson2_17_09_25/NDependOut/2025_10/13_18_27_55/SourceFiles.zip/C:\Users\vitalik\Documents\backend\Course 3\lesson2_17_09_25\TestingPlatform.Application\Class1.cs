﻿namespace TestingPlatform.Application
{
    public class Class1
    {

    }
}
