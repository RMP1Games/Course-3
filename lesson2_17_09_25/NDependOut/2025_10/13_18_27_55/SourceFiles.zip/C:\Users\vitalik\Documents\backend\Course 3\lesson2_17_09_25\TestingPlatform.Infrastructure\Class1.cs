﻿namespace TestingPlatform.Infrastructure
{
    public class Class1
    {

    }
}
