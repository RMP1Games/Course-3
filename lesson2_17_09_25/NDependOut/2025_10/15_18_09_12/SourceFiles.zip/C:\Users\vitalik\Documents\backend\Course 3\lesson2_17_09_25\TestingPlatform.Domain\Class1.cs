﻿namespace TestingPlatform.Domain
{
    public class Class1
    {

    }
}
