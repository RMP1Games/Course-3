﻿namespace TestingPlatform.Domain.Enums
{
    public enum AnswerType
    {
        Single = 1,
        Multiple = 2,
        Text = 3,
    }
}